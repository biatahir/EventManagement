﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonHelpers
{
    public class Literals
    {
        public static string CookieToken = "AuthToken";
        public static string APIToken = "Token";
    }
}
